package constants;

/**
 *
 * @author nixrajput
 */
public enum Role {
    ADMIN, FACULTY, STUDENT;
}
